/// Homepage JavaScript File
/// Here we import all the JavaScript files we need for our homepage.

import './home-page.scss'